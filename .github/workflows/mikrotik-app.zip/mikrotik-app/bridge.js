// Most dla testów w przeglądarce: HTTP (127.0.0.1:8730) <-> API RouterOS (port 8728).
// Uruchom: node bridge.js   (potrzebny Node.js, bez dodatkowych pakietów)
const net=require("net"),http=require("http"),crypto=require("crypto");
let sock=null,buf=Buffer.alloc(0),cur=[],sent=[],pend=null,chain=Promise.resolve();
const enc=w=>{const b=Buffer.from(w,"utf8"),n=b.length;
 const h=n<0x80?Buffer.from([n]):n<0x4000?Buffer.from([(n>>8)|0x80,n&255]):Buffer.from([(n>>16)|0xC0,(n>>8)&255,n&255]);return Buffer.concat([h,b])};
function parse(){for(;;){if(!buf.length)return;const c=buf[0];let n,o;
 if(c<0x80){n=c;o=1}else if((c&0xC0)==0x80){if(buf.length<2)return;n=((c&0x3F)<<8)|buf[1];o=2}
 else if((c&0xE0)==0xC0){if(buf.length<3)return;n=((c&0x1F)<<16)|(buf[1]<<8)|buf[2];o=3}
 else if((c&0xF0)==0xE0){if(buf.length<4)return;n=((c&0x0F)<<24)|(buf[1]<<16)|(buf[2]<<8)|buf[3];o=4}
 else{if(buf.length<5)return;n=buf.readUInt32BE(1);o=5}
 if(buf.length<o+n)return;const w=buf.slice(o,o+n).toString("utf8");buf=buf.slice(o+n);
 if(n===0){sent.push(cur);cur=[];flush()}else cur.push(w)}}
function flush(){while(sent.length&&pend){const s=sent.shift(),t=s[0],row={};
 s.slice(1).forEach(w=>{if(w[0]=="="){const k=w.indexOf("=",1);row[w.slice(1,k)]=w.slice(k+1)}});
 if(t=="!re")pend.rows.push(row);else if(t=="!trap")pend.err=row.message||"trap";
 else if(t=="!done"||t=="!fatal"){if(row.ret)pend.rows.push(row);const p=pend;pend=null;clearTimeout(p.t);
  (t=="!fatal"||p.err)?p.rej(new Error(p.err||"fatal")):p.res(p.rows)}}}
function exec(w){const p=chain.catch(()=>{}).then(()=>new Promise((res,rej)=>{
 const t=setTimeout(()=>{pend=null;rej(new Error("timeout"))},8000);pend={rows:[],res,rej,t};
 sock.write(Buffer.concat([...w.map(enc),Buffer.from([0])]));flush()}));chain=p;return p}
async function connect({host,user,password}){
 if(sock)sock.destroy();buf=Buffer.alloc(0);cur=[];sent=[];pend=null;
 sock=new net.Socket();await new Promise((res,rej)=>{sock.setTimeout(4000,()=>rej(new Error("brak odpowiedzi "+host+":8728")));
  sock.once("error",rej);sock.connect(8728,host,res)});
 sock.setTimeout(0);sock.on("data",d=>{buf=Buffer.concat([buf,d]);parse()});sock.on("error",()=>{});
 const r=await exec(["/login","=name="+user,"=password="+(password||"")]);
 if(r[0]&&r[0].ret){const ch=Buffer.from(r[0].ret,"hex");
  const md=crypto.createHash("md5").update(Buffer.concat([Buffer.from([0]),Buffer.from(password||""),ch])).digest("hex");
  await exec(["/login","=name="+user,"=response=00"+md])}}
http.createServer(async(q,r)=>{
 r.setHeader("Access-Control-Allow-Origin","*");r.setHeader("Access-Control-Allow-Headers","*");r.setHeader("Access-Control-Allow-Private-Network","true");
 if(q.method=="OPTIONS"){r.writeHead(204);return r.end()}
 let b="";for await(const c of q)b+=c;
 try{const d=JSON.parse(b||"{}");let out=[];
  if(q.url=="/connect")await connect(d);else out=await exec(d.words);
  r.writeHead(200,{"Content-Type":"application/json"});r.end(JSON.stringify({rows:out}))}
 catch(e){r.writeHead(500,{"Content-Type":"application/json"});r.end(JSON.stringify({error:String(e.message||e)}))}
}).listen(8730,"127.0.0.1",()=>console.log("Most RouterOS dziala: http://127.0.0.1:8730"));
