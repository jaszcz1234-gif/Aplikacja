# Start dla hAP mini (RB931-2nD). Działa na RouterOS 6 i 7.
# Wgraj plik przez WebFig (Files > Upload), potem w New Terminal: /import hap-mini-start.rsc
# Najpierw zmień wartości poniżej.
:local adminPass "ZMIEN-MNIE"
:local ssid "Dom"
:local wifiPass "ZMIEN-MNIE-WIFI"
:local vpnUser "telefon"
:local vpnPass "ZMIEN-MNIE-VPN"
:local ipsecKey "ZMIEN-MNIE-IPSEC"
:if ($adminPass="ZMIEN-MNIE" || $wifiPass="ZMIEN-MNIE-WIFI" || $vpnPass="ZMIEN-MNIE-VPN" || $ipsecKey="ZMIEN-MNIE-IPSEC") do={:error "Ustaw hasla na poczatku pliku"}

/system identity set name=hap-mini
/user set [find name=admin] password=$adminPass

# Wifi 2.4 GHz (WPA2)
/interface wireless security-profiles add name=pk-sec mode=dynamic-keys authentication-types=wpa2-psk wpa2-pre-shared-key=$wifiPass
/interface wireless set [find default-name=wlan1] ssid=$ssid security-profile=pk-sec mode=ap-bridge disabled=no

# Usługi: API REST/www tylko w sieci domowej, zbędne wyłączone
/ip service set www disabled=no address=192.168.88.0/24
/ip service set api disabled=no address=192.168.88.0/24
/ip service set telnet,ftp disabled=yes
/ip dns set allow-remote-requests=yes
/ip cloud set ddns-enabled=yes

# Przycisk reset: powiadomienie (wymaga pushUrl z parental-control.rsc)
:do {/system routerboard reset-button set enabled=yes} on-error={:log warning "reset-button niedostepny"}

# VPN L2TP/IPsec (WireGuard na tym modelu odradzamy: 32 MB RAM)
/ip pool add name=pk-vpn ranges=10.8.0.10-10.8.0.20
/ppp profile add name=pk-vpn local-address=10.8.0.1 remote-address=pk-vpn
/ppp secret add name=$vpnUser password=$vpnPass profile=pk-vpn service=l2tp
/interface l2tp-server server set enabled=yes use-ipsec=yes ipsec-secret=$ipsecKey default-profile=pk-vpn
/ip firewall filter add chain=input protocol=udp dst-port=500,1701,4500 action=accept comment="pk-vpn" place-before=0
/ip firewall filter add chain=input protocol=ipsec-esp action=accept comment="pk-vpn" place-before=0
:log info "hap-mini-start: gotowe"
