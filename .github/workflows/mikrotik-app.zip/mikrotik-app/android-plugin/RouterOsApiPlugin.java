package pl.mikrotik.kontrola;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

// Klient API binarnego RouterOS (port 8728) dla RouterOS 6 + wymuszenie ruchu przez wifi.
@CapacitorPlugin(name = "RouterOsApi")
public class RouterOsApiPlugin extends Plugin {
  private Socket sock;
  private DataInputStream in;
  private DataOutputStream out;
  private boolean bound = false;

  // Android kieruje ruch przez dane komórkowe, gdy wifi nie ma internetu. To je wiąże z wifi routera.
  @PluginMethod
  public void bindWifi(PluginCall call) {
    final ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
    NetworkRequest rq = new NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
    cm.requestNetwork(rq, new ConnectivityManager.NetworkCallback() {
      @Override public void onAvailable(Network n) {
        cm.bindProcessToNetwork(n);
        if (!bound) { bound = true; call.resolve(); }
      }
      @Override public void onUnavailable() { if (!bound) { bound = true; call.reject("brak wifi"); } }
    });
  }

  @PluginMethod
  public void connect(PluginCall call) {
    final String host = call.getString("host");
    final int port = call.getInt("port", 8728);
    new Thread(() -> {
      try {
        if (sock != null) sock.close();
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, port), 3000);
        s.setSoTimeout(8000);
        sock = s;
        in = new DataInputStream(s.getInputStream());
        out = new DataOutputStream(s.getOutputStream());
        call.resolve();
      } catch (Exception e) { call.reject("polaczenie " + host + ":" + port + " " + e); }
    }).start();
  }

  @PluginMethod
  public void login(PluginCall call) {
    final String u = call.getString("user", "admin");
    final String p = call.getString("password", "");
    new Thread(() -> {
      try {
        synchronized (this) {
          JSArray r = exec(new String[] {"/login", "=name=" + u, "=password=" + p});
          // Starsze RouterOS 6 (< 6.43) zwraca wyzwanie MD5.
          if (r.length() > 0 && r.getJSONObject(0).has("ret")) {
            String ch = r.getJSONObject(0).getString("ret");
            byte[] cb = new byte[ch.length() / 2];
            for (int i = 0; i < cb.length; i++) cb[i] = (byte) Integer.parseInt(ch.substring(2 * i, 2 * i + 2), 16);
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update((byte) 0);
            md.update(p.getBytes(StandardCharsets.UTF_8));
            md.update(cb);
            StringBuilder sb = new StringBuilder("00");
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            exec(new String[] {"/login", "=name=" + u, "=response=" + sb});
          }
        }
        call.resolve();
      } catch (Exception e) { call.reject("logowanie: " + e.getMessage()); }
    }).start();
  }

  @PluginMethod
  public void call(PluginCall call) {
    final JSArray words = call.getArray("words");
    if (words == null) { call.reject("words"); return; }
    new Thread(() -> {
      try {
        synchronized (this) {
          String[] w = new String[words.length()];
          for (int i = 0; i < w.length; i++) w[i] = words.getString(i);
          JSObject r = new JSObject();
          r.put("rows", exec(w));
          call.resolve(r);
        }
      } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }).start();
  }

  private JSArray exec(String[] words) throws Exception {
    for (String w : words) writeWord(w);
    out.write(0); out.flush();
    JSArray rows = new JSArray();
    String err = null;
    while (true) {
      String type = readWord();
      JSObject row = new JSObject();
      while (true) {
        String w = readWord();
        if (w.isEmpty()) break;
        if (w.startsWith("=")) { int k = w.indexOf('=', 1); row.put(w.substring(1, k), w.substring(k + 1)); }
      }
      if (type.equals("!re")) rows.put(row);
      else if (type.equals("!trap")) err = row.optString("message", "trap");
      else if (type.equals("!done")) { if (row.has("ret")) rows.put(row); break; }
      else if (type.equals("!fatal")) { err = "fatal"; break; }
    }
    if (err != null) throw new Exception(err);
    return rows;
  }

  private void writeWord(String w) throws Exception {
    byte[] b = w.getBytes(StandardCharsets.UTF_8);
    int n = b.length;
    if (n < 0x80) out.write(n);
    else if (n < 0x4000) { out.write((n >> 8) | 0x80); out.write(n & 0xFF); }
    else { out.write((n >> 16) | 0xC0); out.write((n >> 8) & 0xFF); out.write(n & 0xFF); }
    out.write(b);
  }

  private String readWord() throws Exception {
    int c = in.read(), n;
    if (c < 0) throw new Exception("rozlaczono");
    if ((c & 0x80) == 0) n = c;
    else if ((c & 0xC0) == 0x80) n = ((c & 0x3F) << 8) | in.read();
    else if ((c & 0xE0) == 0xC0) n = ((c & 0x1F) << 16) | (in.read() << 8) | in.read();
    else n = ((c & 0x0F) << 24) | (in.read() << 16) | (in.read() << 8) | in.read();
    byte[] b = new byte[n];
    in.readFully(b);
    return new String(b, StandardCharsets.UTF_8);
  }
}
