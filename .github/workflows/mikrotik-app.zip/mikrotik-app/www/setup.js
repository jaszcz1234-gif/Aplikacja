// Pierwsza konfiguracja routera z aplikacji (te same kroki co w hap-mini-start.rsc).
const rnd=()=>Math.random().toString(36).slice(2,10);
async function setupRouter(c,log){
 const m=S.model;
 const T=async(name,fn)=>{try{await fn();log(name,1)}catch(e){log(name+": "+(e.message||e),0)}};
 await T("Wifi",async()=>{if(m&&!m.wifi)return;
  try{await Ros.put("/interface/wireless/security-profiles",{name:"pk-sec",mode:"dynamic-keys","authentication-types":"wpa2-psk","wpa2-pre-shared-key":c.wifiPass});
   const w=await Ros.find("/interface/wireless","wlan1");await Ros.patch("/interface/wireless/"+w[".id"],{ssid:c.ssid,"security-profile":"pk-sec",mode:"ap-bridge",disabled:"false"})}
  catch(e){const w=(await Ros.get("/interface/wifi"))[0];await Ros.patch("/interface/wifi/"+w[".id"],{"configuration.ssid":c.ssid,"security.passphrase":c.wifiPass,"security.authentication-types":"wpa2-psk",disabled:"false"})}});
 await T("Usługi",async()=>{for(const n of ["www","api"]){const s=await Ros.find("/ip/service",n);await Ros.patch("/ip/service/"+s[".id"],{disabled:"false",address:"192.168.88.0/24"})}
  for(const n of ["telnet","ftp"]){const s=await Ros.find("/ip/service",n);await Ros.patch("/ip/service/"+s[".id"],{disabled:"true"})}});
 await T("DNS i historia",async()=>{await Ros.cmd("/ip/dns/set",{"allow-remote-requests":"yes"});await Ros.put("/system/logging",{topics:"dns,packet",action:"memory",prefix:"pk"})});
 await T("Nazwa zdalna (cloud)",()=>Ros.cmd("/ip/cloud/set",{"ddns-enabled":"yes"}));
 if(!m||m.wg===false||true)await T("VPN L2TP/IPsec",async()=>{
  await Ros.put("/ip/pool",{name:"pk-vpn",ranges:"10.8.0.10-10.8.0.20"});
  await Ros.put("/ppp/profile",{name:"pk-vpn","local-address":"10.8.0.1","remote-address":"pk-vpn"});
  await Ros.put("/ppp/secret",{name:c.vpnUser,password:c.vpnPass,profile:"pk-vpn",service:"l2tp"});
  await Ros.cmd("/interface/l2tp-server/server/set",{enabled:"yes","use-ipsec":"yes","ipsec-secret":c.ipsec,"default-profile":"pk-vpn"});
  const f=(await Ros.get("/ip/firewall/filter")).find(r=>r.chain==="input");
  await Ros.put("/ip/firewall/filter",{chain:"input",protocol:"udp","dst-port":"500,1701,4500",action:"accept","place-before":f[".id"],comment:"pk-vpn"});
  await Ros.put("/ip/firewall/filter",{chain:"input",protocol:"ipsec-esp",action:"accept","place-before":f[".id"],comment:"pk-vpn"})});
 await T("Przycisk reset",async()=>{if(m&&!m.reset)return;await Ros.cmd("/system/routerboard/reset-button/set",{enabled:"yes"})});
 await T("Hasło administratora",async()=>{const u=await Ros.find("/user","admin");await Ros.patch("/user/"+u[".id"],{password:c.adminPass});await Ros.relogin(c.adminPass)});
 localStorage.setItem("cfg",JSON.stringify(c))}
function wizard(){const c={adminPass:rnd(),ssid:"Dom",wifiPass:rnd()+rnd(),vpnUser:"telefon",vpnPass:rnd()+rnd(),ipsec:rnd()+rnd()};
 app.innerHTML=`<h1>Konfiguracja</h1><div class=card>${[["ssid","Nazwa wifi"],["wifiPass","Hasło wifi"],["adminPass","Hasło routera"],["vpnPass","Hasło VPN"]].map(([k,t])=>`<div class=off style="font-size:12px">${t}</div><input id=c_${k} value="${c[k]}">`).join("")}<button id=run style="width:100%;color:var(--ok)">Skonfiguruj router</button></div><div id=lg></div>`;
 $("#run").onclick=async()=>{for(const k of ["ssid","wifiPass","adminPass","vpnPass"])c[k]=$("#c_"+k).value;$("#run").disabled=true;
  await setupRouter(c,(t,ok)=>$("#lg").insertAdjacentHTML("beforeend",`<div class=in><span>${t}</span><b class="${ok===1?"on":"err"}">${ok===1?"gotowe":"błąd"}</b></div>`));
  $("#lg").insertAdjacentHTML("beforeend",'<div class=off style="font-size:12px">Zapisz hasła w bezpiecznym miejscu.</div><button style="width:100%;margin-top:8px" onclick="home()">Dalej</button>')}}
