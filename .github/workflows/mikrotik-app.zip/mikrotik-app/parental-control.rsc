# Kontrola rodzicielska dla MikroTik (RouterOS 7). Wgraj: /import parental-control.rsc
# Skrypt dopasowuje się do modelu: wifi, WireGuard i przycisk reset są ustawiane tylko tam, gdzie są dostępne.
:global pushUrl "https://TWOJ-SERWER/push"
:local ver [/system resource get version]
:local board [/system resource get board-name]
:log info "pk: start na $board RouterOS $ver"

# 1. API REST w sieci domowej
/ip service set www disabled=no address=192.168.88.0/24
/ip service set api disabled=yes

# 2. Logowanie zapytań DNS do historii stron
/ip dns set allow-remote-requests=yes
:if ([:len [/system logging find where topics~"dns" and prefix="pk"]]=0) do={/system logging add topics=dns,packet action=memory prefix=pk}

# 3. Blokada ręczna (lista pk-blocked) i grupy
:if ([:len [/ip firewall filter find where comment="pk-blocked"]]=0) do={
 /ip firewall filter add chain=forward src-address-list=pk-blocked action=drop comment="pk-blocked" place-before=0}

# 4. Wykrywanie nowych urządzeń i losowych MAC (powiadomienie push)
/ip dhcp-server set [find] lease-script={
 :global pushUrl
 :local mac $leaseActMAC
 :local rnd ([:pick $mac 1 2]~"[26AEae]")
 :if ($leaseBound=1) do={
  :do {/tool fetch url=$pushUrl http-method=post http-data=("{\"event\":\"lease\",\"mac\":\"".$mac."\",\"ip\":\"".$leaseActIP."\",\"random\":".$rnd."}") http-header-field="Content-Type: application/json" keep-result=no} on-error={}
 }}

# 5. Przycisk reset (tylko modele z przyciskiem)
:do {
 /system routerboard reset-button set enabled=yes on-event={
  :global pushUrl
  :do {/tool fetch url=$pushUrl http-method=post http-data="{\"event\":\"reset-button\"}" keep-result=no} on-error={}}
} on-error={:log warning "pk: brak przycisku reset"}

# 6. VPN WireGuard (tylko RouterOS 7)
:if ([:pick $ver 0 1]="7") do={
 :if ([:len [/interface wireguard find where name="pk-wg"]]=0) do={
  /interface wireguard add name=pk-wg listen-port=13231
  /ip address add address=10.8.0.1/24 interface=pk-wg
  /ip firewall filter add chain=input protocol=udp dst-port=13231 action=accept comment="pk-wg"}
} else={:log warning "pk: WireGuard wymaga RouterOS 7"}
:log info "pk: gotowe"
