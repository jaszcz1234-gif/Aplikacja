// Klient RouterOS: REST (v7, port 80) albo API binarne (v6, port 8728 przez wtyczkę RouterOsApi).
window.Ros={mode:"rest",ip:"",u:"",p:"",base:"",auth:"",
 login(ip,u,p){this.ip=ip;this.u=u;this.p=p;this.base="http://"+ip;this.auth="Basic "+btoa(u+":"+p)},
 async rest(method,path,data){
  const o={url:this.base+"/rest"+path,method,headers:{Authorization:this.auth,"Content-Type":"application/json"},data,connectTimeout:3000,readTimeout:5000};
  const H=window.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.CapacitorHttp;
  const r=H?await H.request(o):await fetch(o.url,{method,headers:o.headers,body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(4000)}).then(async x=>({status:x.status,data:await x.json().catch(()=>null)}));
  if(r.status>=400||typeof r.data==="string")throw new Error("HTTP "+r.status);return r.data},
 P(){if(this._p)return this._p;
  if(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform())return this._p=Capacitor.registerPlugin("RouterOsApi");
  const B=async(p,d)=>{const r=await fetch("http://127.0.0.1:8730"+p,{method:"POST",body:JSON.stringify(d)}).catch(()=>{throw new Error("most nie dziala: uruchom node bridge.js")});const j=await r.json();if(j.error)throw new Error(j.error);return j};
  let host="";return this._p={bindWifi:async()=>{},connect:async d=>{host=d.host},login:d=>B("/connect",{host,user:d.user,password:d.password}),call:d=>B("/call",d)}},
 async api(words){return(await this.P().call({words})).rows},
 async connectApi(){const P=this.P();await P.connect({host:this.ip,port:8728});await P.login({user:this.u,password:this.p})},
 attrs:d=>Object.entries(d||{}).map(([k,v])=>`=${k}=${v}`),
 cmd(path,d){return this.mode==="api"?this.api([path,...this.attrs(d)]):this.rest("POST",path,d||{})},
 get(path){return this.mode==="api"?this.api([path+"/print"]):this.rest("GET",path)},
 patch(path,d){const i=path.lastIndexOf("/");return this.cmd(path.slice(0,i)+"/set",{".id":path.slice(i+1),...d})},
 put(path,d){return this.cmd(path+"/add",d)},
 del(path){const i=path.lastIndexOf("/");return this.cmd(path.slice(0,i)+"/remove",{".id":path.slice(i+1)})},
 async find(path,name){return(await this.get(path)).find(x=>x.name===name||x["default-name"]===name)},
 async relogin(p){this.login(this.ip,this.u,p);if(this.mode==="api")await this.connectApi()},
 async detect(u,p,hint){
  const errs=[];
  try{await Promise.race([this.P().bindWifi(),new Promise((_,j)=>setTimeout(()=>j("timeout"),4000))])}catch(e){errs.push("wifi: "+(e.message||e))}
  for(const ip of [hint,"192.168.88.1"].filter(Boolean)){
   this.login(ip,u,p);
   try{this.mode="rest";return{ip,res:await this.rest("GET","/system/resource")}}catch(e){errs.push("REST "+ip+": "+(e.message||e))}
   try{this.mode="api";await this.connectApi();return{ip,res:(await this.api(["/system/resource/print"]))[0]}}catch(e){errs.push("API "+ip+": "+(e.message||e))}}
  throw new Error(errs.join(" | "))},
 isRandomMac:m=>"26AE".includes(m[1].toUpperCase())
};
