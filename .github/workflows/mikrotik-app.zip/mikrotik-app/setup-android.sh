#!/bin/sh
# Uruchom raz w katalogu projektu: tworzy projekt Android i dodaje wtyczkę API RouterOS.
set -e
npm install
npx cap add android
D=android/app/src/main/java/pl/mikrotik/kontrola
cp android-plugin/RouterOsApiPlugin.java $D/
cat > $D/MainActivity.java <<'JAVA'
package pl.mikrotik.kontrola;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b) { registerPlugin(RouterOsApiPlugin.class); super.onCreate(b); }
}
JAVA
sed -i 's#</manifest>#<uses-permission android:name="android.permission.CHANGE_NETWORK_STATE"/><uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/></manifest>#' android/app/src/main/AndroidManifest.xml
npx cap sync
echo "Gotowe: npx cap open android, potem Build > Build APK"
