# MikroTik Kontrola (Capacitor)
Budowa APK: `./setup-android.sh`, potem `npx cap open android` i Build > Build APK.
Skrypt dodaje wtyczkę API RouterOS (android-plugin/RouterOsApiPlugin.java), potrzebną dla RouterOS 6 (np. hAP mini).
RouterOS 7 działa przez REST (port 80), RouterOS 6 przez API (port 8728). Aplikacja wybiera sama.
Pliki hap-mini-start.rsc i parental-control.rsc to ręczna alternatywa.

Test w przeglądarce: zainstaluj Node.js, uruchom `node bridge.js`, otwórz www/index.html. Komputer musi być w sieci routera.

APK w chmurze: wrzuć projekt na GitHub (repozytorium, gałąź main), zakładka Actions > Build APK > Run workflow, pobierz app-debug.apk z Artifacts.
