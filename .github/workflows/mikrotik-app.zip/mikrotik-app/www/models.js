// Baza modeli MikroTik. verify:true = dane do sprawdzenia z mikrotik.com. Pełną bazę generujemy w następnym kroku.
// caps: eth=porty ethernet, wifi=wbudowane wifi, wg=WireGuard (RouterOS 7), reset=przycisk reset, poe=PoE
window.MODELS=[
{id:"hAP ax^3",alias:["C53UiG+5HPaxD2HPaxD"],name:"hAP ax³",eth:5,wifi:true,wg:true,reset:true,poe:true,verify:true},
{id:"hAP ax^2",alias:["C52iG-5HaxD2HaxD"],name:"hAP ax²",eth:5,wifi:true,wg:true,reset:true,poe:false,verify:true},
{id:"hAP ac^2",alias:["RBD52G-5HacD2HnD"],name:"hAP ac²",eth:5,wifi:true,wg:true,reset:true,poe:false,verify:true},
{id:"hAP lite",alias:["RB941-2nD"],name:"hAP lite",eth:4,wifi:true,wg:false,reset:true,poe:false,verify:true},
{id:"hEX",alias:["RB750Gr3"],name:"hEX",eth:5,wifi:false,wg:true,reset:true,poe:false,verify:true},
{id:"hEX S",alias:["RB760iGS"],name:"hEX S",eth:5,wifi:false,wg:true,reset:true,poe:false,verify:true},
{id:"RB5009UG+S+IN",alias:[],name:"RB5009",eth:8,wifi:false,wg:true,reset:true,poe:true,verify:true},
{id:"RB4011iGS+5HacQ2HnD",alias:["RB4011iGS+5HacQ2HnD-IN"],name:"RB4011 wifi",eth:10,wifi:true,wg:true,reset:true,poe:false,verify:true}
{id:"hAP mini",alias:["RB931-2nD"],name:"hAP mini",eth:3,wifi:true,wg:false,reset:true,poe:false,verify:true}
];
window.findModel=(b)=>MODELS.find(m=>m.id===b||m.alias.includes(b))||null;
